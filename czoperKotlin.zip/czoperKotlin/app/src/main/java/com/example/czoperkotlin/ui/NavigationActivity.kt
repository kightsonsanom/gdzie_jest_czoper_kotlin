package com.example.czoperkotlin.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import com.example.czoperkotlin.R
import com.example.czoperkotlin.ui.mapView.MapFragment
import com.example.czoperkotlin.ui.positionList.PositionListFragment
import com.example.czoperkotlin.ui.searchView.SearchFragment

class NavigationActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 100

    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->

        when (item.itemId) {
            R.id.navigation_home -> {
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.container, PositionListFragment(), getString(R.string.geoListFragmentTag))
                    .commit()
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.container, MapFragment(), getString(R.string.mapFragmentTag))
                    .commit()
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.container, SearchFragment(), getString(R.string.searchFragmentTag))
                    .commit()
                return@OnNavigationItemSelectedListener true
            }
        }

        false

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

        if (savedInstanceState == null) {
            val fragment = MapFragment()
            supportFragmentManager.beginTransaction().replace(R.id.container, fragment, getString(R.string.searchFragmentTag))
                .commit()
            navView.selectedItemId = R.id.navigation_dashboard
        }

        checkPermissions()
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSION_REQUEST_CODE
            )
        }
    }
}
