package com.example.czoperkotlin.ui

import android.app.Application

class App: Application(){



}