package com.example.czoperkotlin.ui.positionList

import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.example.czoperkotlin.R
import com.example.czoperkotlin.databinding.PositionListFragmentBinding

class PositionListFragment : Fragment() {

    val mockUserList = mutableListOf("Tomek","Marek","Pawel")
    private lateinit var  binding: PositionListFragmentBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.position_list_fragment, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        initUserList()
    }

    private fun initUserList() {
        val itemsAdapter: ArrayAdapter<String> = ArrayAdapter(activity!!, android.R.layout.simple_list_item_1)

        itemsAdapter.addAll(mockUserList)
        binding.userList.adapter = itemsAdapter
    }
}