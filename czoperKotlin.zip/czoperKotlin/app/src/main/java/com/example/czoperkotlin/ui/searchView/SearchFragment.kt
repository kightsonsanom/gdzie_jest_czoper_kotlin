package com.example.czoperkotlin.ui.searchView

import android.support.v4.app.Fragment

class SearchFragment : Fragment()